/*
 * @Descripttion: 
 * @version: 
 * @Author: Carroll
 * @Date: 2022-03-05 14:49:10
 * @LastEditTime: 2022-03-09 11:36:56
 */

import useRequest from "./api.request"
import { IResPromise } from "./IService"

const BAESURl = "/v3/manager"

/**
 * @name: 获取币种相信
 * @msg: 
 * @param {*}
 * @return {*}
 */
export function getIndexPool() {
    return useRequest.get(`${BAESURl}/getIndexPool`)
}

/**
 * @name: 获取图片
 * @msg: 
 * @param {number} type
 * @param {string} isOpen
 * @return {*}
 */
export function getPictures(type: number, isOpen?: string) {
    return useRequest.get(`${BAESURl}/getPictures`, { params: { type, isOpen } })
}

/**
 * @name: 登录
 * @msg: 
 * @param {object} data
 * @return {*}
 */
export function login(data: { username: string, password: string, place?: string }): IResPromise<any> {
    return useRequest.post(`${BAESURl}/login`, {
        handleError: (value) => value,
        meta: { loading: false },
        data
    })
}


/**
 * @name: 退出
 * @msg: 
 * @param {*}
 * @return {*}
 */
export function signOut() {
    return useRequest.get(`${BAESURl}/signOut`)
}

/**
 * @name: 发送邮箱验证码
 * @msg: 
 * @param {string} email
 * @return {*}
 */
export function sendEmail(email: string) {
    return useRequest.get(`${BAESURl}/sendEmail`, {
        params: { email },
        meta: { loading: false }
    })
}


/**
 * @name: 邮箱注册
 * @msg: 
 * @param {object} data
 * @return {*}
 */
export function registEmail(data: { username: string, email: string, emailCode: string, password: string }) {
    return useRequest.post(`${BAESURl}/registEmail`, { data, meta: { loading: false } })
}


/**
 * @name: 忘记密码
 * @msg: 
 * @param {object} data
 * @return {*}
 */
export function forget(data: { userKey: string, password: string, code: string, type: number }) {
    return useRequest.post(`${BAESURl}/forget`, { data, meta: { loading: false } })
}


/**
 * @name: 获取子账户｜币种
 * @msg: 
 * @param {*}
 * @return {*}
 */
export function usersAndCoins() {
    return useRequest.get(`${BAESURl}/findUsersAndCoins`)
}

/**
 * @name: 获取支持的币种
 * @msg: 
 * @param {*}
 * @return {*}
 */
export function supportCoin() {
    return useRequest.get(`${BAESURl}/getSettingAllCoin`)

}