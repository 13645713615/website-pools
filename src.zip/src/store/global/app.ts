/*
 * @Descripttion: 
 * @version: 
 * @Author: Carroll
 * @Date: 2022-02-26 23:18:13
 * @LastEditTime: 2022-03-09 13:44:56
 */

import { defineStore } from "pinia";
import { localRead, localSave, Constant } from "@/utils/cache";
import { dispatch as dispatchLocale } from "@/locale";
import { getPictures, supportCoin } from "@/service/api";

export type bgColor = "white" | "black";

export interface IState {
    // 国际语言
    language: string,
    // 菜单抽屉
    collapsed: boolean,
    // footer 背景颜色
    footerBgColor: bgColor,
    // 激活
    active: boolean,
    // 所有币种图片
    pictures: Map<number, Record<any, any>>,
    // 支持的币种
    supportCoin: Array<string>,
}

export interface IActions {
    setLanguage(lang: string): Promise<boolean>,
    setCollapsed(value: boolean): void,
    setFooterBgColor(color: bgColor): void,
    loadPictures: (type: number) => Promise<any>,
    loadSupportCoin: () => Promise<any>
};

type AppGetters = {
    getCoinPictures: (state: IState) => Map<string, string>,
    getSupportCoin: (state: IState) => Map<string, string>,

};

export const useApp = defineStore<"app", IState, AppGetters, IActions>({
    id: "app",
    state: () => ({
        language: localRead(Constant.Local) || navigator.languages[1],
        collapsed: false,
        footerBgColor: "black",
        active: false,
        pictures: new Map(),
        supportCoin: []
    }),
    getters: {
        getCoinPictures(state) {
            return new Map(state.pictures.get(7)?.map(({ name, path }) => [name, path]))
        },
        getSupportCoin(state) {
            return new Map(state.supportCoin.map((coin) => [coin, this.getCoinPictures.get(coin)]))
        }
    },
    actions: {
        async setLanguage(lang) {
            const result = await dispatchLocale(lang);
            this.language = result;
            localSave(Constant.Local, result);
            return true;
        },
        setCollapsed(value) {
            this.collapsed = value;
        },
        setFooterBgColor(color) {
            this.footerBgColor = color;
        },
        async loadPictures(type) {
            if (this.pictures.has(type)) return this.pictures.get(type);
            const { data } = await getPictures(type);
            this.pictures.set(type, data as Record<any, any>);
            return data
        },
        async loadSupportCoin() {
            const { data } = await supportCoin();
            this.supportCoin = data
            return data
        }
    }
})

export interface UseAppStore extends IState, IActions { }