/*
 * @Descripttion: 
 * @version: 
 * @Author: Carroll
 * @Date: 2022-02-26 23:18:13
 * @LastEditTime: 2022-03-09 16:43:21
 */

import { login, usersAndCoins } from "@/service/api";
import { defineStore } from "pinia";
import { CacheStorage } from "@/utils/cache"
import { useApp } from "..";

export interface UserInfo {
    email: string,
    phone: string,
    token: string,
    userId: number,
    username: string
}
export interface UsersCoins {
    currency: string,
    coinValue: string,
    coinAddress?: string,
    path: string
}
export interface UsersAccount {
    name: string,
    remarkName: string,
    accountId: number,
    extra?: number,
    children: UsersCoins[]
}

export interface UserState {
    userInfo: UserInfo | null,
    usersAccount: UsersAccount[] | null,
    currentAccountCoin: [number, string | null]
}
export interface UseraActions {
    login(data: { username: string, password: string, place?: string }): Promise<UserInfo>;
    loadUsersCoins(): Promise<UsersAccount[]>;
    setAccount(accountId: number, coin?: string): void;
    setCoin(coin: string): void
}
export type UserGetters = {
    getToken: (state: UserState) => string | undefined,
    getUserCoins: (state: UserState) => UsersCoins[] | undefined,
    getAccount: (state: UserState) => number,
    getCoin: (state: UserState) => string | null,

}

export const useUser = defineStore<"user", UserState, UserGetters, UseraActions>({
    id: "user",
    state: () => ({
        userInfo: null,
        coin: null,
        currentAccountCoin: [-1, null],
        usersAccount: null,
    }),
    getters: {
        getToken(state) {
            return state.userInfo?.token
        },
        getUserCoins(state) {
            return state.usersAccount?.find(({ accountId }) => accountId === this.getAccount)?.children
        },
        getAccount(state) {
            return state.currentAccountCoin[0]
        },
        getCoin(state) {
            return state.currentAccountCoin[1]
        }
    },
    actions: {
        async login(data) {
            const result = await login(data);
            this.userInfo = result.data;
            return result.data
        },
        setAccount(id) {
            const account = this.usersAccount?.find(({ accountId }) => accountId === id)
            if (account) {
                this.currentAccountCoin = [id, account.children[0].coinValue];
            }
        },
        setCoin(coin) {
            this.currentAccountCoin[1] = coin
        },
        async loadUsersCoins() {
            const { getSupportCoin } = useApp();
            const children = [...getSupportCoin.keys()].map((item) => ({ currency: item.toLowerCase(), path: getSupportCoin.get(item), coinValue: item }))
            const list: UsersAccount[] = [{ name: this.userInfo.username, remarkName: "主账户", accountId: -1, children }]
            try {
                const { data } = await usersAndCoins();
                data?.forEach((item) => {
                    const { accountId, currency } = item
                    item.coinValue = currency.toUpperCase();
                    const index = list.findIndex(el => el.accountId == accountId), data = { ...item, extra: 0, path: getSupportCoin.get(item.coinValue) };
                    if (index >= 0) {
                        data.extra = list[index].children.length
                        list[index].children.push(item)
                    } else {
                        list.push({ ...item, extra: list.length, children: [data] })
                    }
                });
            } catch (error) {
                console.error(error)
            }
            this.usersAccount = list;
            this.setAccount(list.at(0).accountId);
            this.setCoin(children.at(0).coinValue);
            return list
        }
    },
    persist: {
        enabled: true,
        strategies: [
            {
                key: "APP_USER_STORE",
                storage: new CacheStorage(2),
                paths: ["userInfo"]
            }
        ]
    },
})