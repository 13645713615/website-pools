/*
 * @Descripttion: 
 * @version: 
 * @Author: Carroll
 * @Date: 2022-02-26 16:50:34
 * @LastEditTime: 2022-03-09 10:50:09
 */
import { strPure } from "@/utils/tools";
import axios from "axios";
import { createI18n, I18n } from "vue-i18n";

const i18n: I18n = createI18n({ silentTranslationWarn: true })

const loadedLanguages: string[] = [];

const localelanguages = import.meta.glob(`./lang/*`);

const localePath: string[] = Object.keys(localelanguages);

const localeName: string[] = localePath.map(path => path.replace(/(.*\/)*([^.]+).*/ig, "$2"));

function setLanguage(lang: string): string {
    i18n.global.locale = lang;
    // axios.defaults.headers.common['Accept-Language'] = lang
    axios.defaults.headers.common['languageType'] = lang
    document.querySelector("html").setAttribute("lang", lang);
    console.info("[LANG] 切换语言" + lang)
    return lang;
}

async function dispatch(lang: string): Promise<string> {
    if (i18n.global.locale !== lang) {
        if (!loadedLanguages.includes(lang)) {
            const path = localePath.find(path => strPure(path).includes(strPure(lang)));
            if (!path) {
                return Promise.reject(new Error("lang file does not exist!"))
            }
            const modules = await localelanguages[path]();
            const { numberFormats, message } = modules!.default
            i18n.global.setLocaleMessage(lang, message);
            i18n.global.setNumberFormat(lang, numberFormats);
        }
        return setLanguage(lang)
    }
    return lang
}

console.info(`[LANG] 国际化语言${localeName.toString()}`)

export { dispatch, localePath, localeName }

export default i18n




