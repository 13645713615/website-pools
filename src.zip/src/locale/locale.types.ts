/*
 * @Descripttion: 
 * @version: 
 * @Author: Carroll
 * @Date: 2022-02-27 10:04:23
 * @LastEditTime: 2022-02-27 10:06:13
 */
export const enum Language {
    
}