/*
 * @Descripttion: 
 * @version: 
 * @Author: Carroll
 * @Date: 2022-02-26 16:57:32
 * @LastEditTime: 2022-03-09 16:57:22
 */

export default {
    numberFormats: {
        currency: {
            style: 'currency',
            currency: 'USD'
        }
    },
    message: {
        locale: "English",
        route: {
            home: "The most advanced mine pool in the world ｜ lhpool",
            statistics: "Statistics",
            blocks: "Blocks",
            miner: "Miners",
            problem: "FAQ",
            service: "Support",
            login: "Login",
            register: "Register",
            forget: "Forget",
            account: "Account",
            mining: "Machine",
            finance: "Finance",
            follow: "Follow",
            extract: "Extract",
            setup:"Settings"
        },
        header: {
            statistics: "Statistics",
            blocks: "Blocks",
            miner: "Miners",
            problem: "FAQ",
            service: "Support",
            mining: "Machine",
            finance: "Finance",
            follow: "Follow",
            extract: "Extract",
            setup:"Settings"
        },
        button: {
            send: "Send",
            login: "Login",
            register: "Register",
            submit: "Submit",
            console: "Console",
            forgetpwd: "Forget password ？",
            registernow: "Register now",
            goLogin: "Go Login",
            signout:"Sign Out",
        },
        profit: {
            daily: "daily",
            monthly: "monthly",
            estimated: "estimated",
            rate: "rate"
        },
        shortcut: {
            join: "Add ore pool",
            configuration: "Mining configuration",
            mining: "Get Started",
            blog: "Blog posts to deepen understanding",
            study: "study",
            help: "help",
            service: "Support",
            contact: "contact us"
        },
        title: {
            currency: "Our currency",
            support: "lhpool ore pool supports multiple currencies",
            characteristic: "lhpool pool features",
            statistics: "Statistics",
            hashrate: "Pool Hashrate",
            blocks: "Blocks",
            history: "Monthly Blocks Visualization",
            miner: "Miner",
            maxMiner: "Top Miners",
            login: "Login",
            register: "Register",
            frorget: "Forget password",
            masterAccount:"Master account",
            subAccount:"Sub account"
        },
        table: {
            coinType: "Coin",
            price: "Price",
            algorithm: "Algorithm",
            avgHashrateprice: "Avg Hashrate Price",
            hashrateFormat: "Hashrate Format",
            defaultMethod: "Revenue Model",
            number: "Number",
            type: "Type",
            date: "Date",
            region: "Region",
            miner: "Miner",
            reward: "Reward",
            roundTime: "RoundTime",
            luck: "Luck",
            wallet: "Miner",
            hashrate: "Hashrate",
            balance: "Balance",
            workers: "Workers",
            joined: "Joined",
        },
        operation: {
            excavation: "excavation",
            agree: "Tick agree"
        },
        footer: {
            contact: "contact us",
            brand: "rand",
            business: "Business cooperation",
            blog: "Blog post",
            service: "Service agreement",
            privacy: "Privacy clause",
            start: "mining",
            common: "FAQ",
            file: "file",
            status: " Service status",
            contactservice: "Support",
            about: " About us",
            help: "Help center",
            community: "Community",
            set: "set up",
        },
        prepare: {
            title: "Are you ready?",
            mining: "Get Started"
        },
        slogan: {
            future: "Building the future of R & D pool",
            innovate: "Cryptocurrency mining pool with continuous innovative research and development",
            faster: "Faster and more stable",
            specialPurpose: "Our dedicated high-performance server cluster and software can handle more than 100 th / S computing power.",
            service: "Enthusiastic service",
            team: "Our team provides you with professional services. You don't have to worry about mining experience."
        },
        statistic: {
            hashrate: "POOL HASHRATE",
            averageLuck: "AVERAGE LUCK",
            miners: "MINERS",
            workers: "WORKERS",
            current: "CURRENT LUCK ",
            nethashrate: "NETWORK HASHRATE",
            netdifficulty: "NETWORK DIFFICULTY"
        },
        verificationCode: {
            reacquire: "Reacquire"
        },
        placeholder: {
            search: "Enter wallet address to view",
            email: "Please enter email address",
            emailCode: "Please enter email verification code",
            username: "Please enter user name",
            password: "Please input a password",
            verifyPassword: "Please confirm the password",
        },
        rules: {
            email: "Please enter email address",
            emailCode: "Please enter email verification code",
            username: "Please enter user name",
            password: "Please input a password",
            verifyPassword: "Please confirm the password",
            passwordatypism: "The two passwords are inconsistent",
        },
        form: {
            email: "Email",
            emailCode: "Email verification code",
            username: "User name",
            password: "Password",
            verifyPassword: "Confirm password",
        },
        tip: {
            sentSuccessfully: "The verification code was sent successfully. Please check it!",
            requestError: "Request error, please try again later!",
            requestFail: "Request fail"
        },
        file: {
            agreement: "《User agreement》"
        }
    }

}