/*
 * @Descripttion: 
 * @version: 
 * @Author: Carroll
 * @Date: 2022-02-26 16:57:32
 * @LastEditTime: 2022-03-09 16:57:21
 */

export default {
    numberFormats: {
        currency: {
            style: 'currency',
            currency: 'CNY'
        }
    },
    message: {
        locale: "简体中文",
        route: {
            home: "世界上最先进的矿池 ｜ lhpool",
            statistics: "矿池统计",
            blocks: "出块记录",
            miner: "矿工数据",
            problem: "常见问题",
            service: "联系客服",
            login: "登录",
            register: "注册",
            forget: "忘记密码",
            account: "账户中心",
            mining: "矿机管理",
            finance: "财务中心",
            follow: "关注钱包",
            extract: "自动提币",
            setup: "账户设置"
        },
        header: {
            statistics: "矿池统计",
            blocks: "出块记录",
            miner: "矿工数据",
            problem: "常见问题",
            service: "联系客服",
            account: "账户中心",
            mining: "矿机管理",
            finance: "财务中心",
            follow: "关注钱包",
            extract: "自动提币",
            setup: "账户设置"
        },
        button: {
            send: "发送验证码",
            login: "登 录",
            register: "注 册",
            submit: "提 交",
            console: "控制台",
            forgetpwd: "忘记密码？",
            registernow: "立即注册",
            goLogin: "已有账号直接去登录",
            signout: "退出登录",
        },
        profit: {
            daily: "每日收益",
            monthly: "每月收益",
            estimated: "预计收益",
            rate: "费率"
        },
        shortcut: {
            join: "加入矿池",
            configuration: "挖矿配置",
            mining: "开始挖矿",
            blog: "博客文章加深了解",
            study: "学习",
            help: "帮助",
            service: "联系客服",
            contact: "联系我们"
        },
        title: {
            currency: "我们的币种",
            support: "lhpool矿池支持多种货币",
            characteristic: "lhpool矿池特色",
            statistics: "矿池统计",
            hashrate: "矿池算力",
            blocks: "出块记录",
            history: "历史矿池区块",
            miner: "矿工数据",
            maxMiner: "最大矿工",
            login: "登 录",
            register: "注 册",
            frorget: "忘记密码",
            masterAccount: "主账户",
            subAccount: "子账户"
        },
        table: {
            coinType: "币种",
            price: "币价",
            algorithm: "算法",
            avgHashrateprice: "实时收益",
            hashrateFormat: "矿池算力",
            defaultMethod: "收益模式",
            number: "区块高度",
            type: "区块类型",
            date: "区块时间",
            region: "矿工所在地区",
            miner: "矿工",
            reward: "区块收益",
            roundTime: "运行时间",
            luck: "幸运值",
            wallet: "钱包",
            hashrate: "算力",
            balance: "当前余额",
            workers: "矿机数量",
            joined: "开户时间",

        },
        operation: {
            excavation: "开挖",
            agree: "勾选同意"
        },
        footer: {
            contact: "联系我们",
            brand: "品牌",
            business: "商务合作",
            blog: "博客文章",
            service: "服务协议",
            privacy: "隐私条款",
            start: "开始挖矿",
            common: "常见问题",
            file: "文档",
            status: "服务状态",
            contactservice: "联系客服",
            about: "关于我们",
            help: "帮助中心",
            community: "lhpool社群",
            set: "设置",
        },
        prepare: {
            title: "准备好了吗?",
            mining: "开始挖矿"
        },
        slogan: {
            future: "构筑研发矿池的未来",
            innovate: "持续创新研发的加密货币采矿池",
            faster: "更快更稳定",
            specialPurpose: "我们矿池专用高性能服务器集群和软件，能处理超过100 TH/s算力。",
            service: "热心服务",
            team: "我们团队为你提供专业服务，挖矿经历不需再担心。",
        },
        statistic: {
            hashrate: "矿池算力",
            averageLuck: "平均幸运值",
            miners: "矿工数量",
            workers: "矿机数量",
            current: "当前幸运值",
            nethashrate: "全网算力",
            netdifficulty: "全网难度"
        },
        verificationCode: {
            reacquire: "重新获取"
        },
        placeholder: {
            search: "输入钱包地址查看",
            email: "请输入邮箱",
            emailCode: "请输入邮箱验证码",
            username: "请输入用户名",
            password: "请输入密码",
            verifyPassword: "请确认密码",
        },
        rules: {
            email: "请输入邮箱",
            emailCode: "请输入邮箱验证码",
            username: "请输入用户名",
            password: "请输入密码",
            verifyPassword: "请确认密码",
            passwordatypism: "两次密码不一致",
        },
        form: {
            email: "邮箱",
            emailCode: "邮箱验证码",
            username: "用户名",
            password: "密码",
            verifyPassword: "确认密码",
        },
        tip: {
            sentSuccessfully: "验证码发送成功，请注意查收!",
            requestError: "请求错误，请稍后再试！",
            requestFail: "请求错误"
        },
        file: {
            agreement: "《用户协议》"
        }
    }
}