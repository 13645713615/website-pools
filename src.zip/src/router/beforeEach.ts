/*
 * @Descripttion: 
 * @version: 
 * @Author: Carroll
 * @Date: 2022-03-05 21:27:44
 * @LastEditTime: 2022-03-09 15:27:15
 */

import { useApp, useUser } from "@/store";
import { RouteLocationNormalized } from "vue-router";

export default async function ({ name, path, meta, query, params, fullPath }: RouteLocationNormalized, from: RouteLocationNormalized) {
    console.log("[ROUTER] " + fullPath)

    const { active, $patch, loadPictures, loadSupportCoin } = useApp();
    if (active == false) {
        await Promise.all([loadPictures(7), loadSupportCoin()]);
        $patch((state) => state.active = true)
    }

    const { getToken } = useUser();
    if (!getToken && meta.visitor) {
        return { name: "login", query: { redirect: fullPath } }
    }

    return true
}