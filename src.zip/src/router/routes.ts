/*
 * @Descripttion: 
 * @version: 
 * @Author: Carroll
 * @Date: 2022-02-26 16:10:44
 * @LastEditTime: 2022-03-08 18:34:39
 */

import { useUser } from '@/store'
import Main from '@/layout/Main'
import { TRoutesRaw } from './router.types'


const routes: TRoutesRaw[] = [
    {
        path: '/',
        name: "",
        redirect: "home",
        component: Main,
        children: [
            {
                path: '/home',
                name: "home",
                component: () => import('@/views/Home'),
                meta: {
                    title: "route.home"
                }
            },
            {
                path: '/blocks',
                name: "blocks",
                component: () => import('@/views/Blocks'),
                meta: {
                    title: "route.blocks"
                }
            },
            {
                path: '/miner',
                name: "miner",
                component: () => import('@/views/Miner'),
                meta: {
                    title: "route.miner"
                }
            },
            {
                path: '/problem',
                name: "problem",
                component: () => import('@/views/Problem'),
                meta: {
                    title: "route.problem"
                }
            },
            {
                path: '/service',
                name: "service",
                component: () => import('@/views/Service'),
                meta: {
                    title: "route.service"
                }
            },
            {
                path: '/statistics',
                name: "statistics",
                component: () => import('@/views/Statistics'),
                meta: {
                    title: "route.statistics"
                }
            },
            {
                path: "/login",
                name: "login",
                component: () => import("@/views/Login"),
                meta: {
                    title: "route.login"
                },
                beforeEnter() {
                    const { getToken } = useUser();
                    if (getToken) return { path: "/" };
                    return true
                },
            },
            {
                path: "/register",
                name: "register",
                component: () => import("@/views/Register"),
                meta: {
                    title: "route.register"
                }
            },
            {
                path: "/forget",
                name: "forget",
                component: () => import("@/views/Forget"),
                meta: {
                    title: "route.forget"
                }
            }
        ]
    },
    {
        path: '/console',
        redirect: "/account",
        name: "console",
        component: () => import('@/layout/Console'),
        children: [
            {
                path: '/account',
                name: "account",
                component: () => import('@/views/Account'),
                meta: {
                    title: "route.account",
                    visitor: true

                }
            },
            {
                path: '/mining',
                name: "mining",
                component: () => import('@/views/Mining'),
                meta: {
                    title: "route.mining",
                    visitor: true

                }
            },
            {
                path: '/finance',
                name: "finance",
                component: () => import('@/views/Finance'),
                meta: {
                    title: "route.finance",
                    visitor: true

                }
            },
            {
                path: '/follow',
                name: "follow",
                component: () => import('@/views/Follow'),
                meta: {
                    title: "route.follow",
                    visitor: true

                }
            },
            {
                path: '/extract',
                name: "extract",
                component: () => import('@/views/Extract'),
                meta: {
                    title: "route.extract",
                    visitor: true

                }
            },
            {
                path: '/setup',
                name: "setup",
                component: () => import('@/views/Setup'),
                meta: {
                    title: "route.setup",
                    visitor: true

                }
            },
        ]
    }
]

export default routes