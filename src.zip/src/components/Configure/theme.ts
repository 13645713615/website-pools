/*
 * @Descripttion: 
 * @version: 
 * @Author: Carroll
 * @Date: 2022-02-27 21:25:21
 * @LastEditTime: 2022-03-07 16:20:25
 */
import { GlobalThemeOverrides } from "naive-ui"

const enum Color {
    Blue = '#0069FF',
    DarkBlue = '#005adb',
    LightBlue = '#217dff',
    SkyBlue = "#1890FF",
    DarkSkyBlue = "#0b86f9",
    LightSkyBlue = "#3198f7"
}

const theme: GlobalThemeOverrides = {
    common: {
        primaryColor: Color.Blue
    },
    Button: {
        colorPrimary: Color.Blue,
        colorPressedPrimary: Color.DarkBlue,
        colorFocusPrimary: Color.LightBlue,
        colorHoverPrimary: Color.LightBlue,

        colorSuccess: Color.SkyBlue,
        colorPressedSuccess: Color.DarkSkyBlue,
        colorFocusSuccess: Color.LightSkyBlue,
        colorHoverSuccess: Color.LightSkyBlue,

        colorDisabledSuccess:Color.SkyBlue,
    },
    Menu: {
        itemTextColorHover: Color.Blue
    },
    Input: {
        borderFocus: "1px solid " + Color.Blue,
        borderHover: "1px solid " + Color.LightBlue,
    },
    Layout: {
        color: "transparent"
    }
}

export default theme