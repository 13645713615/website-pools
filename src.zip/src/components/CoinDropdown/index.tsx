/*
 * @Descripttion: 
 * @version: 
 * @Author: Carroll
 * @Date: 2022-03-08 18:39:47
 * @LastEditTime: 2022-03-09 17:25:09
 */


import { useApp, useUser } from "@/store";
import { UsersCoins } from "@/store/global/user";
import { NAvatar, NDropdown } from "naive-ui";
import { DropdownMixedOption } from "naive-ui/lib/dropdown/src/interface";
import { computed, defineComponent, PropType } from "vue";

export default defineComponent({
    name: "CoinDropdown",
    props: {
        size: {
            type: Number,
            default: 40
        }
    },
    setup() {
        const userStore = useUser();
        const { getCoinPictures } = useApp();
        function createOptions({ coinValue, path }: UsersCoins): DropdownMixedOption {
            return {
                key: coinValue,
                icon: () => <NAvatar size={30} src={path} round ></NAvatar>,
                label: () => <span class="pl-2">{coinValue}</span>
            }
        }

        return {
            options: computed<DropdownMixedOption[]>(() => userStore.getUserCoins?.map(createOptions) || []),
            coinPath: computed<string>(() => getCoinPictures.get(userStore.getCoin)),
            handleSelect(value: string) {
                userStore.setCoin(value)
            }
        }
    },
    render() {
        return (
            <NDropdown  onSelect={this.handleSelect} size="huge" keyboard trigger="click" options={this.options}>
                <NAvatar size={this.size} src={this.coinPath} round class="align-middle"></NAvatar>
            </NDropdown>
        )
    }
})