/*
 * @Descripttion: 
 * @version: 
 * @Author: Carroll
 * @Date: 2022-02-28 18:01:15
 * @LastEditTime: 2022-03-09 17:14:38
 */

import { useUser } from "@/store";
import { NSelect } from "naive-ui";
import { SelectMixedOption } from "naive-ui/lib/select/src/interface";
import { computed, defineComponent, PropType } from "vue";
import { useI18n } from "vue-i18n";

export default defineComponent({
    name: "AccountSelect",
    props: {
        size: String as PropType<'small' | 'medium' | 'large'>,
        showArrow: Boolean
    },
    setup(props) {
        const userStore = useUser();
        const { t } = useI18n()

        function createOptions(): SelectMixedOption[] {
            const [master, ...sub] = userStore.usersAccount || [];
            return [
                {
                    type: 'group',
                    label: t("title.masterAccount"),
                    key: "master",
                    children: [{ value: master?.accountId, label: master?.name }]
                },
                {
                    type: 'group',
                    label: t("title.subAccount"),
                    key: "sub",
                    children: sub?.map(({ accountId, name }) => ({ value: accountId, label: name })) || []
                }
            ]
        }
        return {
            value: computed<number>(() => userStore.getAccount),
            className: computed<string>(() => props.showArrow ? '' : 'select-hide-arrow'),
            options: computed<SelectMixedOption[]>(() => createOptions() || []),
            handleSelect(value: number) {
                userStore.setAccount(value)
            }
        }
    },
    render() {
        return (
            <NSelect class={this.className} value={this.value} size={this.size} onUpdateValue={this.handleSelect} showArrow={this.showArrow} options={this.options} />
        )
    }
})