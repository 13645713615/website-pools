/*
 * @Descripttion: 
 * @version: 
 * @Author: Carroll
 * @Date: 2022-02-28 15:40:39
 * @LastEditTime: 2022-03-02 20:02:33
 */

import { NInput } from "naive-ui";
import { defineComponent, PropType } from "vue";

export default defineComponent({
    name: "Search",
    props: {
        round: Boolean,
        size: String as PropType<'tiny' | 'small' | 'medium' | 'large'>
    },
    render() {
        return (
            <NInput type="text" round={this.round} size={this.size} placeholder={this.$t("placeholder.search")} v-slots={this.$slots} clearable />
        )
    }
})