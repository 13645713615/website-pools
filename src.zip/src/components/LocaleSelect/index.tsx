/*
 * @Descripttion: 
 * @version: 
 * @Author: Carroll
 * @Date: 2022-02-28 18:01:15
 * @LastEditTime: 2022-03-03 00:10:13
 */

import { useApp } from "@/store";
import { NSelect } from "naive-ui";
import { computed, defineComponent, PropType, ref } from "vue";

const localeOptions = JSON.parse(import.meta.env.VITE_APP_LOCALE || '[]') as [string, string][]

export default defineComponent({
    name: "LocaleSelect",
    props: {
        size: String as PropType<'small' | 'medium' | 'large'>,
        showArrow: Boolean
    },
    setup(props) {
        const { setLanguage, $state } = useApp();
        return {
            value: computed(() => $state.language),
            className: computed<string>(() => props.showArrow ? '' : 'select-hide-arrow'),
            options: localeOptions.map(([label, value]) => ({ label, value })),
            setLanguage
        }
    },
    render() {
        return (
            <NSelect class={this.className} value={this.value} size={this.size} onUpdateValue={this.setLanguage} showArrow={this.showArrow} options={this.options} />
        )
    }
})