/*
 * @Descripttion: 
 * @version: 
 * @Author: Carroll
 * @Date: 2022-03-05 09:38:31
 * @LastEditTime: 2022-03-05 13:33:20
 */

import { computed, defineComponent, PropType } from "vue";

interface Option {
    value: string,
    src: string
}

export default defineComponent({
    name: "CoinSwitch",
    props: {
        value: String,
        size: {
            type: String as PropType<'medium' | 'large'>,
            default: "medium"
        },
        option: Array as PropType<Option[]>,
        onChange: Function as PropType<(input: string) => void>
    },
    emits: {
        "change": (input: string) => true
    },
    setup(props, content) {
        function handleInput(event) {
            content.emit("change", event.target.value);
        }
        return {
            type: computed(() => ` coin-switch--${props.size}-type`),
            createWrapper({ value, src }: Option) {
                const checked = props.value == value;
                return (
                    <label key={value} class={"coin-switch-wrapper" + (checked ? " coin-switch--checked" : "")}>
                        <img src={src} alt={value} />
                        <input type="radio" name="coin-switch-radio" checked={checked} onInput={handleInput} value={value} />
                    </label>
                )
            }
        }
    },
    render() {
        return (
            <fieldset class={"coin-switch" + this.type}>
                {this.option.map(this.createWrapper)}
                {this.value && <div class="coin-switch-wrapper min-w-5"> <span>{this.value}</span> </div>}
            </fieldset>

        )
    }
})