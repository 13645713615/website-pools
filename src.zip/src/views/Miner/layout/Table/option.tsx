/*
 * @Descripttion: 
 * @version: 
 * @Author: Carroll
 * @Date: 2022-03-03 13:15:49
 * @LastEditTime: 2022-03-06 11:13:30
 */

import { useApp } from "@/store";
import { Calculator } from "@vicons/ionicons5";
import { DataTableColumns, NAvatar, NButton, NIcon } from "naive-ui";
import { NumberFormat, useI18n } from "vue-i18n";

export interface Columns {
    wallet: string
    hashrate: string
    balance: string
    workers: string
    joined: string
}



export function createColumns(): DataTableColumns<Columns> {
    const { t, n } = useI18n()

    return [
        {
            key: "wallet",
            title: () => t("table.wallet"),
            width: 200,
            ellipsis: {
                tooltip: true
            },
        },
        {
            key: "hashrate",
            width: 100,
            align: "right",
            title: () => t("table.hashrate")
        },
        {
            key: "balance",
            width: 150,
            align: "right",
            title: () => t("table.balance")
        },
        {
            key: "workers",
            width: 140,
            align: "right",
            title: () => t("table.workers")
        },
        {
            key: "joined",
            width: 200,
            align: "right",
            title: () => t("table.joined")
        }
    ]
}

