/*
 * @Descripttion: 
 * @version: 
 * @Author: Carroll
 * @Date: 2022-03-03 11:31:36
 * @LastEditTime: 2022-03-06 11:34:58
 */

import { NDataTable } from "naive-ui";
import { defineComponent } from "vue";
import { createColumns } from "./option";

export default defineComponent({
    name: "Table",
    setup() {
        return {
            columns: createColumns(),
            tableData: {
                loading: false,
                data: [
                    {
                        wallet: "0x5a402eA11EFa6e39Fc5bd83647d0a0A409AAeB62",
                        hashrate: "4.2 GH/s",
                        balance: "2.6098 ETC ",
                        workers: "6",
                        joined: "10 days ago",
                    },
                    {
                        wallet: "0x5a402eA11EFa6e39Fc5bd83647d0a0A409AAeB62",
                        hashrate: "4.2 GH/s",
                        balance: "2.6098 ETC ",
                        workers: "6",
                        joined: "10 days ago",
                    },
                    {
                        wallet: "0x5a402eA11EFa6e39Fc5bd83647d0a0A409AAeB62",
                        hashrate: "4.2 GH/s",
                        balance: "2.6098 ETC ",
                        workers: "6",
                        joined: "10 days ago",
                    },
                    {
                        wallet: "0x5a402eA11EFa6e39Fc5bd83647d0a0A409AAeB62",
                        hashrate: "4.2 GH/s",
                        balance: "2.6098 ETC ",
                        workers: "6",
                        joined: "10 days ago",
                    },
                    {
                        wallet: "0x5a402eA11EFa6e39Fc5bd83647d0a0A409AAeB62",
                        hashrate: "4.2 GH/s",
                        balance: "2.6098 ETC ",
                        workers: "6",
                        joined: "10 days ago",
                    }
                ]
            }
        }
    },
    render() {
        return (
            <div>
                <h2>{this.$t("title.maxMiner")}</h2>
                <NDataTable class="mt-5 table-base" loading={this.tableData.loading} data={this.tableData.data} pagination={false} columns={this.columns} size="large" />
            </div>
        )
    }
})