/*
 * @Descripttion: 
 * @version: 
 * @Author: Carroll
 * @Date: 2022-03-04 13:50:25
 * @LastEditTime: 2022-03-06 11:15:08
 */

import Charts from "@/components/Charts";
import CoinSwitch from "@/components/CoinSwitch";
import Container from "@/layout/Container";
import { NSpace, NCard } from "naive-ui";
import { defineComponent, ref } from "vue";
import Table from "./layout/Table";


const coinOption = [
    { value: "Ethereum Classic", src: "https://static.flexpool.io/assets/coinLogos/small/etc.png" },
    { value: "Chia", src: "https://static.flexpool.io/assets/coinLogos/small/xch.png" }
]

export default defineComponent({
    name: "Miner",
    setup() {
        const coin = ref<string>("Chia");
        function handleCoinChange(value) {
            coin.value = value
        }
        return {
            handleCoinChange,
            coin
        }
    },
    render() {
        return (
            <div class="pt-12 pb-16 bg-slate-700">
                <Container>
                    <NSpace align="center">
                        <h3 class="text-white text-xl">{this.$t("title.miner")}</h3> <CoinSwitch onChange={this.handleCoinChange} value={this.coin} option={coinOption} size="large" />
                    </NSpace>

                    <NCard>
                       <Table></Table>
                    </NCard>
                </Container>
            </div>
        )
    }
})