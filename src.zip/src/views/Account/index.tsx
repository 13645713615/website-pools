/*
 * @Descripttion: 
 * @version: 
 * @Author: Carroll
 * @Date: 2022-03-08 15:54:29
 * @LastEditTime: 2022-03-08 16:11:09
 */

import { defineComponent } from "vue";

export default defineComponent({
    name: "Account",
    render() {
        return (
            <div>1111</div>
        )
    }
})