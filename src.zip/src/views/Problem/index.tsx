/*
 * @Descripttion: 
 * @version: 
 * @Author: Carroll
 * @Date: 2022-03-04 13:50:25
 * @LastEditTime: 2022-03-04 13:51:35
 */

import { defineComponent } from "vue";

export default defineComponent({
    name: "Statistics",
    render() {
        return (
              <div>1111</div>
        )
    }
})