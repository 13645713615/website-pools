/*
 * @Descripttion: 
 * @version: 
 * @Author: Carroll
 * @Date: 2022-03-04 13:50:25
 * @LastEditTime: 2022-03-05 14:29:58
 */

import Charts, { PropsOption } from "@/components/Charts";
import Container from "@/layout/Container";
import { repeatExecution } from "@/utils/tools";
import { NCard, NSpace } from "naive-ui";
import { defineComponent, ref, shallowReactive } from "vue";
import Summary from "./layout/Summary";
import moment from "moment";
import brokenline from "@components/Charts/brokenline"
import CoinSwitch from "@/components/CoinSwitch";

const coinOption = [
    { value: "Ethereum Classic", src: "https://static.flexpool.io/assets/coinLogos/small/etc.png" },
    { value: "Chia", src: "https://static.flexpool.io/assets/coinLogos/small/xch.png" }

]

export default defineComponent({
    name: "Statistics",
    setup() {
        const coin = ref<string>("Chia");

        const chartsData = shallowReactive<PropsOption>({
            xData: [],
            yData: [],
            legend: ["矿池总算力", "亚太地区", "欧洲", "北美"]
        });

        function handleCoinChange(value) {
            coin.value = value

            let x = [], y = [[], [], [], []];
            let date = moment(new Date());
            repeatExecution(function () {
                y.at(0).push(Math.floor(Math.random() * 10 + 100));
                y.at(1).push(Math.floor(Math.random() * 5 + 45));
                y.at(2).push(Math.floor(Math.random() * 12 + 40));
                y.at(3).push(Math.floor(Math.random() * 5 + 25));
                x.push(date.add(1, "days").format("YYYYMMDD"));
            }, 20).then(() => {
                chartsData.yData = y;
                chartsData.xData = x;
            })

        }

        handleCoinChange(coin.value);

        return {
            chartsData,
            coin,
            handleCoinChange
        }
    },
    render() {
        return (
            <div class="pt-12 pb-16 bg-slate-700">
                <Container>
                    <NSpace align="center">
                        <h3 class="text-white text-xl">{this.$t("title.statistics")}</h3> <CoinSwitch onChange={this.handleCoinChange} value={this.coin} option={coinOption} size="large" />
                    </NSpace>

                    <NCard>
                        <Summary />
                        <h2 class="text-center">{this.$t("title.hashrate")}</h2>
                        <Charts class="pt-4" data={this.chartsData} construct={brokenline} style={{ height: "400px" }} />
                    </NCard>
                </Container>
            </div>
        )
    }
})