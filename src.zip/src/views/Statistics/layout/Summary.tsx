/*
 * @Descripttion: 
 * @version: 
 * @Author: Carroll
 * @Date: 2022-03-04 14:46:26
 * @LastEditTime: 2022-03-05 13:45:48
 */

import { AlertCircleOutline } from "@vicons/ionicons5"
import { NCard, NGi, NGrid, NIcon, NNumberAnimation, NStatistic, NTooltip } from "naive-ui"
import { defineComponent } from "vue"

export default defineComponent({
    name: "Summary",
    render() {
        return (
            <div class="flex">
                <NGrid cols={4} responsive="screen" itemResponsive={true}>
                    <NGi span="2 m:1" class="m-2">
                        <NCard class="rounded-md border-light">
                            <NStatistic label={this.$t("statistic.hashrate")} v-slots={{ suffix: () => <span class="text-light" >GH/s</span> }}>
                                <span class="text-light">  <NNumberAnimation showSeparator from={0} to={19}></NNumberAnimation></span>
                            </NStatistic>
                        </NCard>
                    </NGi>

                    <NGi span="2 m:1" class="m-2">
                        <NCard class="rounded-md border-light">
                            <NStatistic v-slots={{ suffix: () => <span class="text-green-300">%</span>, label: () => <span>{this.$t("statistic.averageLuck")}<NTooltip v-slots={{ trigger: () => <NIcon size={14} component={AlertCircleOutline} /> }}>过去30天区块平均幸运值。</NTooltip></span> }}>
                                <span class=" text-green-300"> <NNumberAnimation showSeparator from={0} to={98.05}></NNumberAnimation></span>
                            </NStatistic>
                        </NCard>
                    </NGi>
                    <NGi span="2 m:1" class="m-2">
                        <NCard class="rounded-md border-light">
                            <NStatistic label={this.$t("statistic.miners")}>
                                <span class="text-light"> <NNumberAnimation showSeparator from={0} to={51881}></NNumberAnimation></span>
                            </NStatistic>
                        </NCard>
                    </NGi>
                    <NGi span="2 m:1" class="m-2">
                        <NCard class="rounded-md border-light">
                            <NStatistic label={this.$t("statistic.workers")}>
                                <span class="text-light">  <NNumberAnimation showSeparator from={0} to={219884}></NNumberAnimation></span>
                            </NStatistic>
                        </NCard>
                    </NGi>
                </NGrid>
            </div>
        )
    }
})