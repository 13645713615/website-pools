/*
 * @Descripttion: 
 * @version: 
 * @Author: Carroll
 * @Date: 2022-03-03 13:15:49
 * @LastEditTime: 2022-03-06 17:10:32
 */


import { DataTableColumns } from "naive-ui";
import {  useI18n } from "vue-i18n";

export interface Columns {
    number: number,
    type: string,
    date: string,
    region: string,
    miner: string,
    reward: string,
    roundTime: string,
    luck: string,
}



export function createColumns(): DataTableColumns<Columns> {
    const { t } = useI18n()


    return [
        {
            key: "number",
  
            title: () => t("table.number"),
            width: 180
        },
        {
            key: "type",
            width: 100,
            align: "right",
            title: () => t("table.type")
        },
        {
            key: "date",
            width: 150,
            align: "right",
            title: () => t("table.date")
        },
        {
            key: "region",
            width: 140,
            align: "right",
            title: () => t("table.region")
        },
        {
            key: "miner",
            width: 200,
            align: "right",
            ellipsis: {
                tooltip: true
            },
            title: () => t("table.miner")
        },
        {
            key: "reward",
            width: 180,
            align: "right",
            title: () => t("table.reward"),
        },
        {
            key: "roundTime",
            width: 180,
            title: () => t("table.roundTime"),
        },
        {
            key: "luck",
            width: 180,
            title: () => t("table.luck"),
        },
    ]
}

