/*
 * @Descripttion: 
 * @version: 
 * @Author: Carroll
 * @Date: 2022-03-03 11:31:36
 * @LastEditTime: 2022-03-06 11:16:38
 */

import { NDataTable } from "naive-ui";
import { defineComponent } from "vue";
import { createColumns } from "./option";

export default defineComponent({
    name: "Table",
    setup() {
        return {
            columns: createColumns(),
            tableData: {
                loading: false,
                data: [
                    {
                        number:14665198,
                        type: "Block",
                        date: "4 hours ago",
                        region: "US",
                        miner: "0x5a402eA11EFa6e39Fc5bd83647d0a0A409AAeB62",
                        reward: "3.2022 ETC",
                        roundTime: " 25s",
                        luck: "281.71%"
                    },
                    {
                        number:14665198,
                        type: "Block",
                        date: "4 hours ago",
                        region: "US",
                        miner: "0x5a402eA11EFa6e39Fc5bd83647d0a0A409AAeB62",
                        reward: "3.2022 ETC",
                        roundTime: " 25s",
                        luck: "281.71%"
                    },
                    {
                        number:14665198,
                        type: "Block",
                        date: "4 hours ago",
                        region: "US",
                        miner: "0x5a402eA11EFa6e39Fc5bd83647d0a0A409AAeB62",
                        reward: "3.2022 ETC",
                        roundTime: " 25s",
                        luck: "281.71%"
                    }
                ]
            }
        }
    },
    render() {
        return (
            <div>
                <h2>{this.$t("title.history")}</h2>
                <NDataTable class="mt-5 table-base" loading={this.tableData.loading} data={this.tableData.data} pagination={{pageSize:10}} columns={this.columns} size="large" />
            </div>
        )
    }
})