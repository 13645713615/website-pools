/*
 * @Descripttion: 
 * @version: 
 * @Author: Carroll
 * @Date: 2022-03-04 14:46:26
 * @LastEditTime: 2022-03-06 10:38:57
 */

import { AlertCircleOutline } from "@vicons/ionicons5"
import { NCard, NGi, NGrid, NIcon, NNumberAnimation, NStatistic, NTooltip } from "naive-ui"
import { defineComponent } from "vue"

export default defineComponent({
    name: "Summary",
    render() {
        return (
            <div class="flex">
                <NGrid cols={4} responsive="screen" itemResponsive={true}>
                    <NGi span="2 m:1" class="m-2">
                        <NCard class="rounded-md border-light">
                            <NStatistic v-slots={{ suffix: () => <span class="text-light">%</span>, label: () => <span>{this.$t("statistic.averageLuck")}<NTooltip v-slots={{ trigger: () => <NIcon size={14} component={AlertCircleOutline} /> }}>过去30天区块平均幸运值。</NTooltip></span> }}>
                                <span class="text-light"> <NNumberAnimation showSeparator from={0} to={118.87}></NNumberAnimation></span>
                            </NStatistic>

                        </NCard>
                    </NGi>

                    <NGi span="2 m:1" class="m-2">
                        <NCard class="rounded-md border-light">
                            <NStatistic v-slots={{ suffix: () => <span class="text-green-300">%</span>, label: () => <span>{this.$t("statistic.current")}<NTooltip v-slots={{ trigger: () => <NIcon size={14} component={AlertCircleOutline} /> }}>下一个区块当前的幸运值，实时更新。</NTooltip></span> }}>
                                <span class=" text-green-300"> <NNumberAnimation showSeparator from={0} to={78.53}></NNumberAnimation></span>
                            </NStatistic>
                        </NCard>
                    </NGi>
                    <NGi span="2 m:1" class="m-2">
                        <NCard class="rounded-md border-light">
                            <NStatistic label={this.$t("statistic.nethashrate")} v-slots={{ suffix: () => <span class="text-light">TH</span>}}>
                                <span class="text-light"> <NNumberAnimation showSeparator from={0} to={305.7}></NNumberAnimation></span>
                            </NStatistic>
                        </NCard>
                    </NGi>
                    <NGi span="2 m:1" class="m-2">
                        <NCard class="rounded-md border-light">
                            <NStatistic label={this.$t("statistic.netdifficulty")} v-slots={{ suffix: () => <span class="text-light">TH/s</span>}}>
                                <span class="text-light">  <NNumberAnimation showSeparator from={0} to={23.4 }></NNumberAnimation></span>
                            </NStatistic>
                        </NCard>
                    </NGi>
                </NGrid>
            </div>
        )
    }
})