/*
 * @Descripttion: 
 * @version: 
 * @Author: Carroll
 * @Date: 2022-03-04 13:50:25
 * @LastEditTime: 2022-03-06 10:46:02
 */

import Charts, { PropsOption } from "@/components/Charts";
import Container from "@/layout/Container";
import { repeatExecution } from "@/utils/tools";
import { NCard, NSpace } from "naive-ui";
import { defineComponent, ref, shallowReactive } from "vue";
import Summary from "./layout/Summary";
import moment from "moment";
import blendline from "@components/Charts/blendline"
import CoinSwitch from "@/components/CoinSwitch";
import Table from "./layout/Table";

const coinOption = [
    { value: "Ethereum Classic", src: "https://static.flexpool.io/assets/coinLogos/small/etc.png" },
    { value: "Chia", src: "https://static.flexpool.io/assets/coinLogos/small/xch.png" }

]

export default defineComponent({
    name: "Blocks",
    setup() {
        const coin = ref<string>("Chia");

        const chartsData = shallowReactive<PropsOption>({
            xData: [],
            yData: [],
            legend: ["Difficulty", "Blocks"]
        });

        function handleCoinChange(value) {
            coin.value = value

            let x = [], y = [[], [], [], []];
            let date = moment(new Date());
            repeatExecution(function () {
                y.at(0).push(Math.floor(Math.random() * 5 + 5));
                y.at(1).push(Math.floor(Math.random() * 5));
                x.push(date.add(1, "days").format("YYYYMMDD"));
            }, 20).then(() => {
                chartsData.yData = y;
                chartsData.xData = x;
            })

        }

        handleCoinChange(coin.value);

        return {
            chartsData,
            coin,
            handleCoinChange
        }
    },
    render() {
        return (
            <>
                <div class="pt-12 pb-16 bg-slate-700">
                    <Container>
                        <NSpace align="center">
                            <h3 class="text-white text-xl">{this.$t("title.blocks")}</h3> <CoinSwitch onChange={this.handleCoinChange} value={this.coin} option={coinOption} size="large" />
                        </NSpace>

                        <NCard>
                            <Summary />
                            <h2 class="text-center">{this.$t("title.history")}</h2>
                            <Charts class="pt-4" data={this.chartsData} construct={blendline} style={{ height: "400px" }} />
                        </NCard>
                    </Container>
                </div>
                <div class="pt-5 pb-12">
                    <Container >
                        <Table></Table>
                    </Container>
                </div>
            </>
        )
    }
})