/*
 * @Descripttion: 
 * @version: 
 * @Author: Carroll
 * @Date: 2022-03-08 15:54:29
 * @LastEditTime: 2022-03-08 18:11:20
 */

import { defineComponent } from "vue";

export default defineComponent({
    name: "Extract",
    render() {
        return (
            <div>1111</div>
        )
    }
})