/*
 * @Descripttion: 
 * @version: 
 * @Author: Carroll
 * @Date: 2022-03-08 15:54:29
 * @LastEditTime: 2022-03-09 18:21:35
 */


import Container from "@/layout/Container";
import { defineComponent } from "vue";
import Table from "./layout/Table";

export default defineComponent({
    name: "Follow",
    render() {
        return (
            <div class="pt-12 pb-16 bg-slate-700">
                <Container>
                    <Table></Table>
                </Container>

            </div>
        )
    }
})