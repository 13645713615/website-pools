/*
 * @Descripttion: 
 * @version: 
 * @Author: Carroll
 * @Date: 2022-03-02 21:51:04
 * @LastEditTime: 2022-03-03 00:18:42
 */

import { AddCircleOutline, AlertCircleOutline } from "@vicons/ionicons5";
import { NAvatar, NButton, NCard, NIcon, NSpace, NTooltip } from "naive-ui";
import { defineComponent } from "vue";

export default defineComponent({
    name: "Card",
    render() {
        return (
            <NCard class="shadow">
                <div class="relative">
                    <NAvatar class="absolute" round size={60} />
                    <NSpace class="pl-20" vertical>
                        <div>
                            <strong class="font-extrabold block text-2xl">Ethereum</strong>
                            <span class="text-gray-500">{this.$t("profit.estimated")} <NTooltip v-slots={{ trigger: () => <NIcon class="align-middle" size={16} component={AlertCircleOutline} /> }}>预计收益按过往七天矿池收入计算。</NTooltip> </span>
                        </div>
                        <div class="pt-6">
                            <span  >100MH/s{this.$t("profit.monthly")}  </span>
                            <p class="m-0 mt-2">
                                <b class="font-medium text-xl">US$3.42</b>
                                <span class="text-gray-500">≈0.001451 ETH</span>
                            </p>
                        </div>
                        <div class="pt-6">
                            <span  >100MH/s{this.$t("profit.monthly")}  </span>
                            <p class="m-0 mt-2">
                                <b class="font-medium text-xl">US$3.42</b>
                                <span class="text-gray-500">≈0.001451 ETH</span>
                            </p>
                        </div>

                        <div class=" pt-3 flex justify-between items-end">
                            <span class="text-gray-500">{this.$t("profit.rate")} 0.7% (PPLNS)  <NTooltip v-slots={{ trigger: () => <NIcon class="align-middle" size={16} component={AddCircleOutline} /> }}>额外加成 MEV（矿工可提取价值）+ 90% 收入</NTooltip> </span>
                            <NButton type="success">{this.$t("header.miner")}</NButton>
                        </div>
                    </NSpace>

                </div>
            </NCard>
        )
    }
})
