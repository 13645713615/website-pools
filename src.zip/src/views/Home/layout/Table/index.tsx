/*
 * @Descripttion: 
 * @version: 
 * @Author: Carroll
 * @Date: 2022-03-03 11:31:36
 * @LastEditTime: 2022-03-05 18:19:33
 */

import { useService } from "@/hooks/service";
import { getIndexPool } from "@/service/api";
import { NDataTable } from "naive-ui";
import { defineComponent } from "vue";
import { createColumns } from "./option";

export default defineComponent({
    name: "Table",
    setup() {
        const tableData = useService(getIndexPool, { immediate: true, defaultValue: [] });

        return {
            columns: createColumns(),
            tableData
        }
    },
    render() {
        return (
            <div>
                <div class="text-center">
                    <b class="block text-2xl font-semibold">{this.$t("title.currency")}</b>
                    <p>{this.$t("title.support")}</p>
                </div>
                <NDataTable class="mt-5 table-base" loading={this.tableData.loading} data={this.tableData.data} pagination={false} columns={this.columns} size="large" />
            </div>
        )
    }
})