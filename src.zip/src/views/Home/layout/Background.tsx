/*
 * @Descripttion: 
 * @version: 
 * @Author: Carroll
 * @Date: 2022-03-02 18:23:20
 * @LastEditTime: 2022-03-04 10:02:30
 */

import Container from "@/layout/Container";
import { defineComponent, renderSlot, } from "vue";

export default defineComponent({
    name: "Background",
    render() {
        return (
            <div class="w-ful bg-slate-700 text-white pt-16 relative" style="height: 543px;">
                <Container class="text-center ">
                    <h1 class="text-3xl leading-none">{this.$t("slogan.future")}</h1>
                    <p class="text-base leading-none">{this.$t("slogan.innovate")}</p>
                    <div class="relative">
                        <div class="mt-8 text-left absolute w-full z-10">{renderSlot(this.$slots, "default")}</div>
                    </div>
                    <span class="circular large float-left mt-8 " >{this.$t("header.mining")}</span>
                </Container>
                <Container class="absolute bottom-0 text-right left-0 right-0">
                    <span class="circular small mr-10">{this.$t("header.statistics")}</span>
                    <span class="circular small mr-10" >{this.$t("header.blocks")}</span>
                    <span class="circular small ">{this.$t("header.miner")}</span>
                </Container>
            </div>
        )
    }
})