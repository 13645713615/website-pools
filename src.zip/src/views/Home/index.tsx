/*
 * @Descripttion: 
 * @version: 
 * @Author: Carroll
 * @Date: 2022-02-26 15:59:43
 * @LastEditTime: 2022-03-06 18:29:19
 */

import { NButton, NGi, NGrid, NIcon } from "naive-ui"
import { defineComponent } from "vue";
import Background from "./layout/Background";
import Search from "@components/Search";
import { Search as SearchIcon } from "@vicons/ionicons5"
import Card from "./layout/Card"
import Container from "@/layout/Container";
import Shortcut from "./layout/Shortcut";
import Table from "./layout/Table";
import Characteristic from "./layout/Characteristic";
import { useTemporaryFooterBgColor } from "@/hooks";

export default defineComponent({
    setup() {
        useTemporaryFooterBgColor("white")
    },
    render() {
        return (
            <div>
                {/* 大屏 */}
                <Background>
                    <div class="max-w-screen-sm flex m-auto">
                        <Search size="large" round class="flex-1" />
                        <NButton size="large" type="primary" class="md:ml-3 ml-2" round><NIcon component={SearchIcon} />  </NButton>
                    </div>
                </Background>
                <Container class="mt-5">
                    {/* 卡片 */}
                    <NGrid class="profit-grid" cols={12} responsive="screen" itemResponsive={true}>
                        <NGi span="12 m:6 l:4">
                            <Card></Card>
                        </NGi>
                        <NGi span="12 m:6 l:4">
                            <Card></Card>
                        </NGi>
                        <NGi span="12 m:6 l:4">
                            <Card></Card>
                        </NGi>
                    </NGrid>
                    {/* 快捷导航 */}
                    <Shortcut class="pt-12"></Shortcut>
                    {/* 表格 */}
                    <Table class="pt-12 pb-12"></Table>
                </Container>
                {/* 矿池特色 */}
                <Characteristic />

                <div class="bg-primary">
                    <Container class="pt-12 pb-12 flex items-center justify-between md:flex-row flex-col text-white">
                        <h2 class="text-3xl">{this.$t("prepare.title")}</h2>
                        <NButton size="large" class="bg-white">{this.$t("prepare.mining")}</NButton>
                    </Container>
                </div>
            </div >
        )
    }
})