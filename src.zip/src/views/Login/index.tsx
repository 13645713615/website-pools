/*
 * @Descripttion: 
 * @version: 
 * @Author: Carroll
 * @Date: 2022-03-06 11:40:33
 * @LastEditTime: 2022-03-08 17:38:52
 */

import { defineComponent, reactive, ref } from "vue";
import { FormInst, FormRules, NAlert, NButton, NForm, NFormItem, NInput, NSpace } from "naive-ui";
import Subscriber from "@/layout/Subscriber";
import { useUser } from "@/store";
import { RouterLink, useRoute, useRouter } from "vue-router";

const rules: FormRules = {
    username: [
        { required: true, message: '请输入邮箱', trigger: 'blur' }
    ],
    password: [
        { required: true, message: '请输入密码', trigger: 'blur' }
    ]
}

export default defineComponent({
    name: "Login",
    setup() {
        const { login } = useUser();
        const { replace } = useRouter();
        const { query } = useRoute();
        const formRef = ref<FormInst | null>(null);
        const loading = ref<boolean>(false);
        const alert = reactive({ visible: false, message: "" });
        const formData = reactive({
            username: "",
            password: ""
        })

        return {
            formRef,
            alert,
            loading,
            formData,
            handleSubmit() {
                formRef.value?.validate((errors) => {
                    if (!errors) {
                        loading.value = true;
                        login(formData).then(() => {
                            alert.visible = false;
                            replace({ path: query?.redirect as string | undefined || "/console" })
                        }).catch(res => {
                            alert.visible = true;
                            alert.message = res.message;
                        }).finally(() => {
                            loading.value = false
                        })
                    }
                })
            }
        }
    },
    render() {
        return (
            <Subscriber class="md:pb-28 md:h-auto h-so  md:pt-24  pt-12">
                <div class="w-full lg:max-w-lg md:max-w-md xl:max-w-xl  m-auto  md:shadow md:bg-white md:text-black md:p-4 rounded-lg ">
                    <NForm showLabel={false} onSubmit={this.handleSubmit} size="large" ref={(ref) => this.formRef = ref} class="md:text-current text-white" rules={rules} model={this.formData} >
                        <NSpace justify="space-between" align="center" >
                            <h1 class="text-xl mb-6 text-current">{this.$t("title.login")}</h1>
                            <RouterLink to="/register" class="text-current mr-2"><NButton text class="text-current underline">{this.$t("button.registernow")}</NButton></RouterLink>
                        </NSpace>
                        {this.alert.visible && <NAlert class="mb-3" type="error" closable onClose={() => this.alert.visible = false}>{this.alert.message}</NAlert>}
                        <NFormItem path="username">
                            <NInput type="text" v-model={[this.formData.username, "value"]} placeholder={this.$t("form.username")}></NInput>
                        </NFormItem>
                        <NFormItem path="password">
                            <NInput type="password" v-model={[this.formData.password, "value"]} placeholder={this.$t("form.password")}></NInput>
                        </NFormItem>
                        <NSpace justify="space-between" class="block pr-2 pl-2 pb-4">
                            <RouterLink to="/forget" class="text-current"><NButton text class="text-current">{this.$t("button.forgetpwd")}</NButton></RouterLink>
                        </NSpace>
                        <div class="text-center">
                            <NButton type="success" class="w-full md:w-auto" size="large" loading={this.loading} attrType="submit">{this.$t("button.login")}</NButton>
                        </div>
                    </NForm>
                </div>
            </Subscriber>
        )
    }
})


