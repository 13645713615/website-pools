/*
 * @Descripttion: 
 * @version: 
 * @Author: Carroll
 * @Date: 2022-02-27 18:13:43
 * @LastEditTime: 2022-03-07 16:38:02
 */

import { defineComponent, renderSlot } from "vue"
export default defineComponent({
    name: "Container",
    render() {
        return (
            <section  class="container max-w-screen-xl mx-auto px-4">{renderSlot(this.$slots, "default")}</section>
        )
    }
})