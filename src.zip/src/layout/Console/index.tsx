/*
 * @Descripttion: 
 * @version: 
 * @Author: Carroll
 * @Date: 2022-03-08 16:12:34
 * @LastEditTime: 2022-03-09 18:15:51
 */

import { NButton, NLayout } from "naive-ui";
import { defineComponent } from "vue";
import Content from "../Content";
import Footer from "../Footer";
import Header from "../Header";
import { ExpandetMenu, ContractileMenu } from "../Menu";
import Screen from "@components/Screen"
import Drawer from "../Drawer";
import Accordion from "../Menu/Accordion";
import { smallMenuOptions, useConsoleMenu, useUserMenu } from "../Menu/option";
import CoinDropdown from "@/components/CoinDropdown";
import { useUser } from "@/store";
import AccountSelect from "@/components/AccountSelect";
import UserMenu from "../Menu/UserMenu";
import { useLogout } from "@/hooks";
import { useI18n } from "vue-i18n";

export default defineComponent({
    name: "Console",
    setup() {
        const { menuLeftOptions } = useConsoleMenu();
        useUser().loadUsersCoins();
        const { t } = useI18n()
        return {
            ScreenSlotsTemplate: {
                default: () => (<ExpandetMenu left={menuLeftOptions}><AccountSelect class="md:w-24" /><CoinDropdown /><UserMenu /></ExpandetMenu>),
                other: () => {
                    const userMenu = useUserMenu()
                    userMenu.pop();
                    return <><ContractileMenu options={smallMenuOptions} /><Drawer><Accordion options={[].concat(menuLeftOptions, userMenu)}><AccountSelect /><NButton type="error" block onClick={() => useLogout()}>{t("button.signout")}</NButton></Accordion></Drawer></>
                }
            }
        }
    },
    render() {
        return (
            <NLayout class="h-screen">
                <Header class="sticky top-0 z-50">
                    <Screen size="large" v-slots={this.ScreenSlotsTemplate}></Screen>
                </Header>
                <Content {...{ id: "content" }}></Content>
                <Footer></Footer>
            </NLayout>
        )
    }
})
