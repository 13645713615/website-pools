/*
 * @Descripttion: 
 * @version: 
 * @Author: Carroll
 * @Date: 2022-02-26 16:22:03
 * @LastEditTime: 2022-03-08 17:35:53
 */

import { NAlert, NButton, NLayout } from "naive-ui";
import { Component, computed, defineComponent } from "vue";
import Content from "../Content";
import Footer from "../Footer";
import Header from "../Header";
import { ExpandetMenu, ContractileMenu } from "../Menu";
import Screen from "@components/Screen"
import Drawer from "../Drawer";
import Accordion from "../Menu/Accordion";
import { useMenu, iconMenuOptions } from "../Menu/option";
import { useI18n } from "vue-i18n";
import { userVisitoRender } from "@/hooks";
import { RouterLink } from "vue-router";

export default defineComponent({
    name: "Main",
    setup() {
        const { menuLeftOptions, menuRightOptions } = useMenu();
        const { t } = useI18n()
        const visitoRender = computed<Component>(() => userVisitoRender(
            <>
                <RouterLink class="block" to="/register"><NButton class="w-full lg:w-auto">{t("button.register")}</NButton></RouterLink>
                <RouterLink class="block" to="/login"><NButton class="w-full lg:w-auto" type="primary" >{t("button.login")}</NButton></RouterLink>
            </>,
            <RouterLink class="block" to="/console"><NButton class="w-full lg:w-auto" type="primary">{t("button.console")}</NButton></RouterLink>
        ))

        return {
            ScreenSlotsTemplate: {
                default: () => (<ExpandetMenu left={menuLeftOptions} right={menuRightOptions}>{visitoRender.value}</ExpandetMenu>),
                other: () => (<><ContractileMenu options={iconMenuOptions} /><Drawer><Accordion options={[].concat(menuLeftOptions, menuRightOptions)}>{visitoRender.value}</Accordion></Drawer></>)
            }
        }
    },
    render() {
        return (
            <NLayout class="h-screen">
                <Header class="sticky top-0 z-50">
                    <Screen size="large" v-slots={this.ScreenSlotsTemplate}></Screen>
                </Header>
                <NAlert class="global-alert sticky top-16 z-40" showIcon={false} closable={true}>
                    <div class="text-center text-white">
                        亚洲直連挖礦連接：<br />
                        TCP端口：hke.fpmirror.com:13271<br />
                        SSL端口：hke.fpmirror.com:5555<br />
                        亚洲备用地址： web.fpmirror.com<br />
                        請注意，挖掘連接可能會更改。 如果您想永久避免所有限制，請通過HTTPS（DoH）配寘DNS並使用lhpool.org
                    </div>
                </NAlert>
                <Content {...{ id: "content" }}></Content>
                <Footer></Footer>
            </NLayout>
        )
    }
})