/*
 * @Descripttion: 
 * @version: 
 * @Author: Carroll
 * @Date: 2022-02-27 15:53:19
 * @LastEditTime: 2022-03-05 13:29:55
 */

import LocaleSelect from '@/components/LocaleSelect';
import Container from '@/layout/Container';
import { useApp } from '@/store';
import { NButton, NDivider, NGi, NGrid, NLayoutFooter } from 'naive-ui';
import { computed, CSSProperties, defineComponent } from "vue";


export default defineComponent({
    name: "Footer",
    setup() {
        const { $state } = useApp();
        return {
            theme: computed<CSSProperties>(() => {
                const backgroundColor = $state.footerBgColor
                return {
                    backgroundColor: backgroundColor === "white" ? backgroundColor : "#313437",
                    color: backgroundColor === "white" ? "black" : "white"
                }

            })
        }
    },
    render() {
        return (
            <NLayoutFooter style={this.theme}>
                <Container class="pt-10 pb-3">
                    <NGrid class="profit-grid" cols={20} responsive="screen" itemResponsive={true}>
                        <NGi span="20 s:10 m:5 l:4">
                            <ul class="footer-nav">
                                <li><b class="text-primary text-lg">{this.$t("footer.about")}</b></li>
                                <li><NButton class="text-current" tag='a' text >{this.$t("footer.contact")}</NButton></li>
                                <li><NButton class="text-current" tag='a' text >{this.$t("footer.brand")}</NButton></li>
                                <li><NButton class="text-current" tag='a' text >{this.$t("footer.business")}</NButton></li>
                                <li><NButton class="text-current" tag='a' text >{this.$t("footer.blog")}</NButton></li>
                                <li><NButton class="text-current" tag='a' text >{this.$t("footer.service")}</NButton></li>
                                <li><NButton class="text-current" tag='a' text >{this.$t("footer.privacy")}</NButton></li>
                            </ul>
                        </NGi>
                        <NGi span="20 s:10 m:5 l:4">
                            <ul class=" footer-nav">
                                <li><b class="text-primary text-lg">{this.$t("footer.help")}</b></li>
                                <li><NButton class="text-current" tag='a' text >{this.$t("footer.start")}</NButton></li>
                                <li><NButton class="text-current" tag='a' text >{this.$t("footer.common")}</NButton></li>
                                <li><NButton class="text-current" tag='a' text >Transparency Reports</NButton></li>
                                <li><NButton class="text-current" tag='a' text >API {this.$t("footer.file")}</NButton></li>
                                <li><NButton class="text-current" tag='a' text >Gasprice.io</NButton></li>
                            </ul>
                        </NGi>
                        <NGi span="20 s:10 m:5 l:4">
                            <ul class=" footer-nav">
                                <li><b class="text-primary text-lg">{this.$t("footer.community")}</b></li>
                                <li><NButton class="text-current" tag='a' text >Discord</NButton></li>
                                <li><NButton class="text-current" tag='a' text >Reddit</NButton></li>
                                <li><NButton class="text-current" tag='a' text >Telegram</NButton></li>
                                <li><NButton class="text-current" tag='a' text >Telegram (中文)</NButton></li>
                            </ul>
                        </NGi>
                        <NGi span="20 s:10 m:5 l:4">
                            <ul class=" footer-nav">
                                <li><b class="text-primary text-lg">{this.$t("footer.contact")}</b></li>
                                <li><NButton class="text-current" tag='a' text >{this.$t("footer.status")}</NButton></li>
                                <li><NButton class="text-current" tag='a' text >{this.$t("footer.contactservice")}</NButton></li>
                            </ul>
                        </NGi>
                        <NGi span="20 l:4">
                            <ul class=" footer-nav">
                                <li><b class="text-primary text-lg">{this.$t("footer.set")}</b></li>
                                <li><LocaleSelect size="large" showArrow={true} /></li>
                                <li></li>
                            </ul>
                        </NGi>
                    </NGrid>
                    <NDivider />
                    <p class="text-center">© 2020-2022 lhexpool.io 或附属机构。保留所有权利。</p>
                </Container>
            </NLayoutFooter>
        )

    }
})