/*
 * @Descripttion: 
 * @version: 
 * @Author: Carroll
 * @Date: 2022-03-06 14:18:30
 * @LastEditTime: 2022-03-07 18:03:37
 */

import { defineComponent, renderSlot } from "vue";
import Container from "../Container";

export default defineComponent({
    name: "Subscriber",
    render() {
        return (
            <div class="pt-12 pb-16 bg-slate-700 text-white">
                <Container >
                        {renderSlot(this.$slots, "default")}
                </Container>
            </div>
        )
    }
})

// <div class=" bg-slate-700 text-white relative overflow-hidden">
// <img src={backgroundImage} class="min-w-full min-h-full md:w-full md:block hidden" /> 
// <Container class=" absolute z-10  top-12 w-full left-0 right-0">
//     {renderSlot(this.$slots, "default")}
// </Container>
// </div>