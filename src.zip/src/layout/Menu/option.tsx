/*
 * @Descripttion: 
 * @version: 
 * @Author: Carroll
 * @Date: 2022-02-27 17:39:37
 * @LastEditTime: 2022-03-09 17:31:32
 */
import { DropdownOption, MenuOption, NButton, NIcon } from 'naive-ui';
import { useI18n } from "vue-i18n";
import { Search, CellularSharp, Recording } from "@vicons/ionicons5"
import { OpenDrawerBut } from '../Drawer';
import { RouterLink } from 'vue-router';
import { useLogout } from '@/hooks';
import CoinDropdown from '@/components/CoinDropdown';

export function useMenu(): { menuLeftOptions: MenuOption[], menuRightOptions: MenuOption[] } {
    const { t } = useI18n();
    return {
        menuLeftOptions: [
            {
                key: "statistics", label: () => <RouterLink to={{ name: "statistics" }} class="menu-text">{t("header.statistics")}</RouterLink >
            },
            {
                key: "blocks", label: () => <RouterLink to={{ name: "blocks" }} class="menu-text">{t("header.blocks")}</RouterLink>
            },
            {
                key: "miner", label: () => <RouterLink to={{ name: "miner" }} class="menu-text">{t("header.miner")}</RouterLink >
            }
        ],
        menuRightOptions: [
            {
                key: "problem", label: () => <RouterLink to={{ name: "problem" }} class="menu-text">{t("header.problem")}</RouterLink>
            },
            {
                key: "service", label: () => <RouterLink to={{ name: "service" }} class="menu-text">{t("header.service")}</RouterLink >
            }
        ]
    }
}


export const iconMenuOptions: MenuOption[] = [
    {
        key: "statistics", label: () => <NButton size="large" tag="a" text v-slots={{ icon: () => <NIcon component={CellularSharp} /> }}></NButton>
    },
    {
        key: "blocks", label: () => <NButton size="large" tag="a" text v-slots={{ icon: () => <NIcon component={Recording} /> }}></NButton>
    },
    {
        key: "search", label: () => <NButton size="large" tag="a" text v-slots={{ icon: () => <NIcon component={Search} /> }}></NButton>
    },
    {
        key: "menu", label: () => <OpenDrawerBut size="large"></OpenDrawerBut>
    }
]


export function useConsoleMenu(): { menuLeftOptions: MenuOption[], menuRightOptions: MenuOption[] } {
    const { t } = useI18n();
    return {
        menuLeftOptions: [
            {
                key: "account", label: () => <RouterLink to={{ name: "account" }} class="menu-text">{t("header.account")}</RouterLink >
            },
            {
                key: "mining", label: () => <RouterLink to={{ name: "mining" }} class="menu-text">{t("header.mining")}</RouterLink >
            },
            {
                key: "finance", label: () => <RouterLink to={{ name: "finance" }} class="menu-text">{t("header.finance")}</RouterLink >
            },
            {
                key: "extract", label: () => <RouterLink to={{ name: "extract" }} class="menu-text">{t("header.extract")}</RouterLink >
            }
        ],
        menuRightOptions: []
    }
}

export function useUserMenu(): DropdownOption[] {
    const { t } = useI18n();
    return [
        {
            key: "setup", label: () => <RouterLink to={{ name: "setup" }} class="menu-text">{t("header.setup")}</RouterLink >
        },
        {
            key: "follow", label: () => <RouterLink to={{ name: "follow" }} class="menu-text">{t("header.follow")}</RouterLink >
        },
        {
            key: "signout", label: () => <NButton text onClick={() => useLogout()}>{t("button.signout")}</NButton>
        }
    ]
}

export const smallMenuOptions: MenuOption[] = [
    {
        key: "coin", label: () => <CoinDropdown size={20} />
    },
    {
        key: "search", label: () => <NButton size="large" tag="a" text v-slots={{ icon: () => <NIcon component={Search} /> }}></NButton>
    },
    {
        key: "menu", label: () => <OpenDrawerBut size="large"></OpenDrawerBut>
    }
]