/*
 * @Descripttion: 
 * @version: 
 * @Author: Carroll
 * @Date: 2022-03-08 18:19:12
 * @LastEditTime: 2022-03-09 15:53:34
 */

import { Person } from "@vicons/ionicons5";
import { NAvatar, NDropdown, NIcon } from "naive-ui";
import { defineComponent } from "vue";
import { useUserMenu } from "./option";

export default defineComponent({
    name: "UserMenu",
    setup() {
        return {
            options: useUserMenu()
        }
    },
    render() {
        return (
            <NDropdown trigger="click" keyboard options={this.options}>
                <NAvatar size={40} round class="align-middle">
                    <NIcon component={<Person />}></NIcon>
                </NAvatar>
            </NDropdown>
        )
    }
})