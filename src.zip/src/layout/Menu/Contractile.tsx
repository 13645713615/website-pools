/*
 * @Descripttion: 
 * @version: 
 * @Author: Carroll
 * @Date: 2022-02-28 15:15:50
 * @LastEditTime: 2022-03-08 17:06:22
 */

import { defineComponent, PropType } from "vue";
import { NMenu } from 'naive-ui';
import { MenuMixedOption } from "naive-ui/lib/menu/src/interface";
export default defineComponent({
    name: "Contractile",
    props:{
        options: Array as PropType<MenuMixedOption[]>,
    },
    render() {
        return (
            <NMenu class="contractile-menu float-right" options={this.options} mode="horizontal" />
        )
    }
})