/*
 * @Descripttion: 
 * @version: 
 * @Author: Carroll
 * @Date: 2022-02-28 15:16:22
 * @LastEditTime: 2022-03-09 16:11:41
 */

import { defineComponent, PropType, renderSlot } from "vue";
import {  NIcon, NMenu, NSpace } from 'naive-ui';
import Search from "@/components/Search";
import { SearchOutline } from "@vicons/ionicons5"
import { MenuMixedOption } from "naive-ui/lib/menu/src/interface";

export default defineComponent({
    name: "Expandet",
    props: {
        left: Array as PropType<MenuMixedOption[]>,
        right: Array as PropType<MenuMixedOption[]>,
    },
    render() {
        return (
            <div class="flex items-center">
                <NMenu options={this.left} class="float-left" mode="horizontal" />
                <div class="flex-1 flex items-center justify-end">
                    <div class="flex-1 max-w-xs  min-w-5 mr-5"><Search round v-slots={{ prefix: () => <NIcon component={SearchOutline} /> }} /></div>
                    <NMenu options={this.right} class="float-right" mode="horizontal" />
                    <NSpace align="center" size={18} class="ml-2">
                        {renderSlot(this.$slots, "default")}
                    </NSpace>
                </div>
            </div>
        )
    }
})