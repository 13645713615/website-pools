/*
 * @Descripttion: 
 * @version: 
 * @Author: Carroll
 * @Date: 2022-03-04 13:43:34
 * @LastEditTime: 2022-03-09 13:32:57
 */

import { signOut } from "@/service/api";
import { useApp, useUser } from "@/store";
import { bgColor } from "@/store/global/app";
import { onBeforeUnmount } from "vue";
import { useRoute } from "vue-router";
import router from "@/router";
export * from "./resize"
export * from "./service"
/**
 * @name: 临时修改底部背景
 * @msg: 
 * @param {bgColor} color
 * @return {*}
 */
function useTemporaryFooterBgColor(color: bgColor) {
    const { setFooterBgColor, footerBgColor } = useApp();
    setFooterBgColor(color);
    onBeforeUnmount(() => {
        setFooterBgColor(footerBgColor)
    })
}


/**
 * @name: 是否是游客
 * @msg: 
 * @param {T} ifSolots
 * @param {T} elseSolots
 * @return {*}
 */
function userVisitoRender<T = any>(ifSolots: T, elseSolots?: T): T {
    const { getToken } = useUser();
    return !getToken ? ifSolots : elseSolots
}

function useLogout() {
    signOut().finally(() => {
        useUser().$reset();
        router.push({ name: "login", query: { redirect: location.pathname } })
    })
}

export { useTemporaryFooterBgColor, userVisitoRender, useLogout }