/*
 * @Descripttion: 
 * @version: 
 * @Author: Carroll
 * @Date: 2022-02-26 15:04:53
 * @LastEditTime: 2022-03-09 15:34:18
 */
/// <reference types="vite/client" />

declare module "*.vue" {
  import type { DefineComponent } from "vue";
  // eslint-disable-next-line @typescript-eslint/no-explicit-any, @typescript-eslint/ban-types
  const component: DefineComponent<{}, {}, any>;
  export default component;
}

interface ImportMetaEnv {
  VITE_APP_BASE: string;
  VITE_APP_BASE_API: string;

  VITE_APP_XNPOOL_LINK: string;
  VITE_APP_PEOXY_TARGET: string;
  VITE_APP_KEEPALIVE_ALIVEMAX: string;
  // 国际化
  VITE_APP_LOCALE: string
}


declare function WeakRef(...args: any): void { }
declare function FinalizationRegistry(...args: any): void { }

